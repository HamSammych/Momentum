import { useCallback, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  RefreshControl,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useFocusEffect } from '@react-navigation/native';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { hexToRgba } from '@/constants/Colors';
import { supabase } from '@/lib/supabase';
import { Task, Category } from '@/types/database';
import { TaskCard } from '@/components/TaskCard';
import { TaskCardSkeleton, StatCardSkeleton } from '@/components/Skeleton';
import { Plus, Flame, CheckCircle2 } from 'lucide-react-native';
import Animated, {
  FadeIn,
  FadeInDown,
  FadeInUp,
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withRepeat,
  withSequence,
  withTiming,
  withDelay,
  Easing,
} from 'react-native-reanimated';
import { useReducedMotion } from '@/hooks/useReducedMotion';

export default function HomeScreen() {
  const { user, profile } = useAuth();
  const { colors } = useTheme();
  const router = useRouter();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const reduceMotion = useReducedMotion();
  const fabScale = useSharedValue(1);
  const fabStyle = useAnimatedStyle(() => ({
    transform: [{ scale: fabScale.value }],
  }));

  const streakScale = useSharedValue(1);
  const streakAnimStyle = useAnimatedStyle(() => ({
    transform: [{ scale: streakScale.value }],
  }));

  const streak = profile?.current_streak || 0;

  useEffect(() => {
    if (streak > 0 && !reduceMotion) {
      streakScale.value = withDelay(
        600,
        withRepeat(
          withSequence(
            withTiming(1.15, { duration: 800, easing: Easing.inOut(Easing.ease) }),
            withTiming(1, { duration: 800, easing: Easing.inOut(Easing.ease) })
          ),
          -1,
          true
        )
      );
    } else {
      streakScale.value = 1;
    }
  }, [streak, reduceMotion]);

  const loadData = useCallback(async () => {
    if (!user) return;

    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const { data: tasksData } = await supabase
        .from('tasks')
        .select('*')
        .eq('user_id', user.id)
        .or(`due_date.gte.${today.toISOString()},due_date.is.null`)
        .order('position', { ascending: true })
        .limit(20);

      const { data: categoriesData } = await supabase
        .from('categories')
        .select('*')
        .eq('user_id', user.id);

      if (tasksData) setTasks(tasksData);
      if (categoriesData) setCategories(categoriesData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user]);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const onRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  const toggleTaskStatus = async (task: Task) => {
    const newStatus = task.status === 'done' ? 'todo' : 'done';
    const updates: any = { status: newStatus };

    if (newStatus === 'done') {
      updates.completed_at = new Date().toISOString();
    } else {
      updates.completed_at = null;
    }

    await supabase.from('tasks').update(updates).eq('id', task.id);
    setTasks((prev) =>
      prev.map((t) => (t.id === task.id ? { ...t, ...updates } : t))
    );
  };

  const deleteTask = async (taskId: string) => {
    await supabase.from('tasks').delete().eq('id', taskId);
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
  };

  const todayTasks = tasks.filter((t) => {
    if (!t.due_date) return false;
    const taskDate = new Date(t.due_date);
    const today = new Date();
    return taskDate.toDateString() === today.toDateString();
  });

  const upcomingTasks = tasks.filter((t) => {
    if (!t.due_date) return true;
    const taskDate = new Date(t.due_date);
    const today = new Date();
    return taskDate > today && taskDate.toDateString() !== today.toDateString();
  });

  const completedToday = todayTasks.filter((t) => t.status === 'done').length;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
      >
        <Animated.View entering={FadeIn.duration(600)} style={styles.hero}>
          <Text style={[styles.greeting, { color: colors.textTertiary }]}>
            Welcome back,
          </Text>
          <Text style={[styles.name, { color: colors.text }]} accessibilityRole="header">
            {profile?.full_name || 'there'}
          </Text>
          <Text style={[styles.tagline, { color: colors.textTertiary }]}>
            Make today count.
          </Text>
        </Animated.View>

        {loading ? (
          <View style={styles.statsRow}>
            <StatCardSkeleton />
            <StatCardSkeleton />
          </View>
        ) : (
          <View style={styles.statsRow}>
            <Animated.View
              entering={FadeInDown.delay(150).springify()}
              style={[
                styles.statCard,
                {
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                },
              ]}
            >
              <Animated.View style={[styles.statIconWrap, { backgroundColor: hexToRgba(colors.primary, 0.08) }, streakAnimStyle]}>
                <Flame size={28} color={colors.primary} />
              </Animated.View>
              <Text style={[styles.statValue, { color: colors.text }]}>
                {streak}
              </Text>
              <Text style={[styles.statLabel, { color: colors.textTertiary }]}>
                Day Streak
              </Text>
            </Animated.View>

            <Animated.View
              entering={FadeInDown.delay(250).springify()}
              style={[
                styles.statCard,
                {
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                },
              ]}
            >
              <View style={[styles.statIconWrap, { backgroundColor: colors.primaryAlpha10 }]}>
                <CheckCircle2 size={28} color={colors.primary} />
              </View>
              <Text style={[styles.statValue, { color: colors.text }]}>
                {profile?.total_tasks_completed || 0}
              </Text>
              <Text style={[styles.statLabel, { color: colors.textTertiary }]}>
                Completed
              </Text>
            </Animated.View>
          </View>
        )}

        {todayTasks.length > 0 && (
          <Animated.View
            entering={FadeInDown.delay(350).springify()}
            style={styles.section}
          >
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.text }]} accessibilityRole="header">
                Today
              </Text>
              <Text
                style={[styles.sectionCount, { color: colors.textTertiary }]}
              >
                {completedToday}/{todayTasks.length}
              </Text>
            </View>
            {todayTasks.map((task, index) => (
              <TaskCard
                key={task.id}
                task={task}
                onPress={() => router.push(`/tasks/${task.id}`)}
                onToggleStatus={() => toggleTaskStatus(task)}
                onDelete={() => deleteTask(task.id)}
                index={index}
              />
            ))}
          </Animated.View>
        )}

        {upcomingTasks.length > 0 && (
          <Animated.View
            entering={FadeInDown.delay(450).springify()}
            style={styles.section}
          >
            <Text style={[styles.sectionTitle, { color: colors.text }]} accessibilityRole="header">
              Upcoming
            </Text>
            {upcomingTasks.slice(0, 5).map((task, index) => (
              <TaskCard
                key={task.id}
                task={task}
                onPress={() => router.push(`/tasks/${task.id}`)}
                onToggleStatus={() => toggleTaskStatus(task)}
                onDelete={() => deleteTask(task.id)}
                index={index}
              />
            ))}
          </Animated.View>
        )}

        {loading && (
          <View style={styles.section}>
            <TaskCardSkeleton />
            <TaskCardSkeleton />
            <TaskCardSkeleton />
          </View>
        )}

        {todayTasks.length === 0 &&
          upcomingTasks.length === 0 &&
          !loading && (
            <Animated.View
              entering={FadeIn.delay(300).duration(400)}
              style={styles.empty}
            >
              <Text style={[styles.emptyTitle, { color: colors.text }]}>
                No tasks yet
              </Text>
              <Text
                style={[styles.emptyText, { color: colors.textTertiary }]}
              >
                Tap the + button to create your first task
              </Text>
            </Animated.View>
          )}

        <View style={{ height: 140 }} />
      </ScrollView>

      <Animated.View
        entering={reduceMotion ? undefined : FadeInUp.delay(500).springify()}
        style={[styles.fab, { backgroundColor: colors.primary, shadowColor: colors.primary }, fabStyle]}
      >
        <Pressable
          onPress={() => router.push('/tasks/new')}
          onPressIn={() => {
            if (!reduceMotion) fabScale.value = withSpring(0.88, { damping: 15, stiffness: 400 });
          }}
          onPressOut={() => {
            if (!reduceMotion) fabScale.value = withSpring(1, { damping: 15, stiffness: 400 });
          }}
          style={styles.fabInner}
          accessibilityRole="button"
          accessibilityLabel="Create new task"
        >
          <Plus size={28} color="#FFFFFF" strokeWidth={2.5} />
        </Pressable>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scroll: {
    paddingHorizontal: 40,
    paddingTop: 80,
    paddingBottom: 40,
  },
  hero: {
    marginBottom: 48,
    paddingTop: 16,
  },
  greeting: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    marginBottom: 6,
    letterSpacing: 0.3,
  },
  name: {
    fontSize: 48,
    fontFamily: 'Inter-Bold',
    letterSpacing: -1.5,
    lineHeight: 56,
  },
  tagline: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    marginTop: 12,
    letterSpacing: 0.1,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 48,
  },
  statCard: {
    flex: 1,
    padding: 32,
    borderRadius: 24,
    alignItems: 'center',
    gap: 14,
    borderWidth: 1,
  },
  statIconWrap: {
    width: 56,
    height: 56,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statValue: {
    fontSize: 40,
    fontFamily: 'Inter-Bold',
    letterSpacing: -1.5,
  },
  statLabel: {
    fontSize: 11,
    fontFamily: 'Inter-SemiBold',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  section: {
    marginBottom: 40,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 22,
    fontFamily: 'Inter-Bold',
    letterSpacing: -0.5,
    marginBottom: 20,
  },
  sectionCount: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    marginBottom: 20,
  },
  empty: {
    alignItems: 'center',
    paddingVertical: 80,
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 22,
    fontFamily: 'Inter-Bold',
    letterSpacing: -0.3,
    marginBottom: 10,
  },
  emptyText: {
    fontSize: 15,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    lineHeight: 24,
  },
  fab: {
    position: 'absolute',
    bottom: 88,
    right: 32,
    width: 64,
    height: 64,
    borderRadius: 32,
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.5,
    shadowRadius: 24,
    elevation: 20,
    zIndex: 10,
  },
  fabInner: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

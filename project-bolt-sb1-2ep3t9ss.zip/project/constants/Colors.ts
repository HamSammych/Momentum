const baseDarkPalette = {
  background: '#000000',
  surface: '#0A0A0A',
  surfaceLight: '#141414',
  text: '#FAFAFA',
  textSecondary: '#A1A1AA',
  textTertiary: '#71717A',
  border: '#1E1E1E',
  white: '#FFFFFF',
  black: '#000000',
  error: '#EF4444',
  warning: '#F59E0B',
  success: '#10B981',
};

export const Colors = {
  dark: baseDarkPalette,
  light: baseDarkPalette,
};

export const DEFAULT_ACCENT = '#6366F1';

export const categoryColors = [
  '#71717A',
  '#A1A1AA',
  '#52525B',
  '#3F3F46',
  '#27272A',
  '#18181B',
  '#D4D4D8',
  '#E4E4E7',
  '#6B7280',
  '#9CA3AF',
  '#4B5563',
  '#374151',
];

export function hexToRgba(hex: string, alpha: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function generateAccentShades(hex: string) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);

  const lighten = (value: number, amount: number) => Math.min(255, value + amount);
  const darken = (value: number, amount: number) => Math.max(0, value - amount);

  return {
    primary: hex,
    primaryLight: `rgb(${lighten(r, 40)}, ${lighten(g, 40)}, ${lighten(b, 40)})`,
    primaryDark: `rgb(${darken(r, 40)}, ${darken(g, 40)}, ${darken(b, 40)})`,
    primaryAlpha10: `rgba(${r}, ${g}, ${b}, 0.10)`,
    primaryAlpha20: `rgba(${r}, ${g}, ${b}, 0.20)`,
  };
}

export function getPriorityColors(accent: string) {
  const shades = generateAccentShades(accent);

  return {
    low: shades.primaryLight,
    medium: shades.primary,
    high: shades.primaryDark,
  };
}

export function getPriorityStyle(priority: 'low' | 'medium' | 'high', accent: string) {
  const shades = generateAccentShades(accent);

  const map = {
    low: { dot: shades.primaryLight, bg: shades.primaryAlpha10 },
    medium: { dot: shades.primary, bg: shades.primaryAlpha20 },
    high: { dot: shades.primaryDark, bg: shades.primaryAlpha20 },
  };

  return map[priority] || { dot: '#71717A', bg: 'rgba(113,113,122,0.10)' };
}